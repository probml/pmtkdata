load CBCLfaces 
montage(reshape(X(:,:,1:100),[19 19 1 100]))
 